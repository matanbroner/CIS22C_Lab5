/*
=== Lab 5 ===
Design a birthday to name database that implements a binary search tree and is able to add, remove, and modify data in the tree.
Use various traversal methods over the BST and include a print out in two distinct file logs given by the user.

Partner rating (Matan to Timo): 0
*/

#include <iostream>
#include "BirthdayDatabase.h"
using namespace std;
int main()
{
	string outputFile;
	cout << "=== Welcome to the 'Name and Birthday Logger' ===" << endl << endl;

	cout << "Provide an INCOMPLETE file address for your NAMES and DATES output files [file will be named for you, provide only a path]" << endl;
	cout << "--> ";
	getline(cin, outputFile);

	BirthdayDatabase database(outputFile); // create database
	database.displayMenu(); // run menu program in database

	return 0;
}